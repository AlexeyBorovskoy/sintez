#include "config.h"
#include "snmp_handler.h"
#include "tcp_client.h"
#include "object_manager.h"
#include "spectr_protocol.h"
#include <iostream>
#include <map>
#include <memory>
#include <atomic>
#include <signal.h>
#include <unistd.h>

static std::atomic<bool> running(true);
static std::map<std::string, std::unique_ptr<SpectrObject>> objects;
static std::unique_ptr<SNMPHandler> snmpHandler;
static std::unique_ptr<TcpClient> tcpClient;

void signalHandler(int signal) {
    std::cout << "\nReceived signal " << signal << ", shutting down..." << std::endl;
    running = false;
}

void processITSData(const std::string& data) {
    // Парсинг потока данных от ITS сервера
    static std::map<uint32_t, std::string> buffers; // Буферы по ID объекта
    
    // Разделение по \r
    size_t pos;
    std::string remaining = data;
    
    while ((pos = remaining.find('\r')) != std::string::npos) {
        std::string line = remaining.substr(0, pos);
        remaining = remaining.substr(pos + 1);
        
        if (line.empty()) continue;
        
        // Парсинг команды
        auto parsed = SpectrProtocol::parseCommand(line);
        
        if (!parsed.isValid) {
            continue;
        }
        
        // Попытка определить ID объекта из команды
        // В протоколе Spectr-ITS команды могут содержать ID объекта
        // Если не указан, используем первый объект
        uint32_t targetId = 0;
        
        // Поиск объекта по ID (если указан в команде)
        // В production нужна более сложная логика определения объекта
        SpectrObject* targetObject = nullptr;
        
        if (!objects.empty()) {
            // Пока используем первый объект, в production нужна маршрутизация
            targetObject = objects.begin()->second.get();
        }
        
        if (targetObject) {
            targetObject->processCommand(parsed);
        } else {
            std::cerr << "No object found for command: " << parsed.command << std::endl;
        }
    }
}

void processSNMPNotification(const SNMPNotification& notification) {
    // Поиск объекта по адресу источника
    auto it = objects.find(notification.sourceAddress);
    if (it != objects.end()) {
        it->second->processNotification(notification);
    } else {
        std::cout << "Tlc object " << notification.sourceAddress << " not registered!" << std::endl;
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <config.json>" << std::endl;
        return 1;
    }
    
    // Установка обработчика сигналов
    signal(SIGINT, signalHandler);
    signal(SIGTERM, signalHandler);
    
    // Загрузка конфигурации
    Config config;
    if (!ConfigLoader::load(argv[1], config)) {
        std::cerr << "Failed to load configuration" << std::endl;
        return 1;
    }
    
    std::cout << "Loaded configuration:" << std::endl;
    std::cout << "  ITS: " << config.its.host << ":" << config.its.port << std::endl;
    std::cout << "  Community: " << config.community << std::endl;
    std::cout << "  Objects: " << config.objects.size() << std::endl;
    
    // Инициализация SNMP handler
    snmpHandler = std::make_unique<SNMPHandler>(config.community);
    
    // Инициализация TCP клиента для ITS сервера
    tcpClient = std::make_unique<TcpClient>(
        config.its.host, 
        config.its.port, 
        config.its.reconnectTimeout
    );
    
    tcpClient->setDataCallback(processITSData);
    tcpClient->setErrorCallback([](const std::string& error) {
        std::cerr << "TCP Client error: " << error << std::endl;
    });
    
    if (!tcpClient->start()) {
        std::cerr << "Failed to start TCP client" << std::endl;
        return 1;
    }
    
    // Создание объектов
    for (const auto& objConfig : config.objects) {
        std::string key = objConfig.addr.empty() ? objConfig.siteId : objConfig.addr;
        
        auto tcpClientPtr = tcpClient.get();
        auto obj = std::make_unique<SpectrObject>(objConfig, snmpHandler.get(), tcpClientPtr);
        
        objects[key] = std::move(obj);
        
        std::cout << "Created object: " << objConfig.strid 
                  << " (ID: " << objConfig.id 
                  << ", Addr: " << objConfig.addr << ")" << std::endl;
    }
    
    // Запуск SNMP trap receiver
    if (!snmpHandler->startReceiver(10162, processSNMPNotification)) {
        std::cerr << "Failed to start SNMP receiver" << std::endl;
        return 1;
    }
    
    std::cout << "Spectr UTMC bridge started successfully" << std::endl;
    std::cout << "SNMP receiver listening on port 10162" << std::endl;
    std::cout << "Connecting to ITS server: " << config.its.host << ":" << config.its.port << std::endl;
    
    // Основной цикл
    while (running) {
        sleep(1);
        
        // Обновление состояний объектов
        for (auto& pair : objects) {
            pair.second->updateState();
        }
    }
    
    // Остановка сервисов
    std::cout << "Shutting down..." << std::endl;
    snmpHandler->stopReceiver();
    tcpClient->stop();
    
    objects.clear();
    snmpHandler.reset();
    tcpClient.reset();
    
    std::cout << "Shutdown complete" << std::endl;
    return 0;
}
