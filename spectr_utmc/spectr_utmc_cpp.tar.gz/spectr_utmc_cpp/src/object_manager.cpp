#include "object_manager.h"
#include <iostream>
#include <sstream>
#include <ctime>
#include <algorithm>
#include <cstdint>
#include <chrono>
#include <netsnmp/asn1.h>

SpectrObject::SpectrObject(const ObjectConfig& config, SNMPHandler* snmpHandler, TcpClient* tcpClient)
    : config_(config), snmpHandler_(snmpHandler), tcpClient_(tcpClient),
      eventCounter_(0), eventMask_(1), stageStartTime_(0), cycleStartTime_(0) {
    
    // Создание SNMP сессии для этого объекта
    if (snmpHandler_) {
        snmpHandler_->createSession(config.addr, "UTMC");
    }
}

SpectrObject::~SpectrObject() {
}

void SpectrObject::processNotification(const SNMPNotification& notification) {
    std::cout << "Inform from " << notification.sourceAddress << std::endl;
    
    std::map<std::string, uint8_t> stateChanges;
    bool hasTakt = false;
    bool hasStage = false;
    bool hasRegime = false;
    bool hasControlSource = false;
    
    uint8_t takt = 0;
    uint8_t stage = 0;
    uint8_t regime = 0;
    uint8_t controlSource = 0;
    
    for (const auto& varbind : notification.varbinds) {
        processSNMPVarbind(varbind);
        
        // Обработка специфичных OID
        if (varbind.oid == SNMPOID::UTC_REPLY_GN_1) {
            // Takt
            try {
                takt = static_cast<uint8_t>(std::stoi(varbind.value));
                hasTakt = true;
            } catch (...) {}
        } else if (varbind.oid == SNMPOID::UTC_REPLY_GN) {
            // Stage
            try {
                stage = static_cast<uint8_t>(std::stoi(varbind.value));
                hasStage = true;
            } catch (...) {}
        } else if (varbind.oid == SNMPOID::UTC_REPLY_FR) {
            // Regime (Flashing Amber)
            try {
                int value = std::stoi(varbind.value);
                if (value != 0) {
                    regime = 2;
                    hasRegime = true;
                }
            } catch (...) {}
        } else if (varbind.oid == SNMPOID::UTC_TYPE2_OPERATION_MODE) {
            // Control Source
            try {
                int value = std::stoi(varbind.value);
                controlSource = (value == 3) ? 3 : 1;
                hasControlSource = true;
            } catch (...) {}
        }
    }
    
    // Формирование изменений состояния
    if (hasTakt) {
        stateChanges["stage"] = takt;
        if (hasStage) {
            stateChanges["transition"] = (stage == takt) ? 0 : 255;
        }
    } else if (hasStage && stage > 48) {
        stateChanges["stage"] = stage - 48;
        stateChanges["transition"] = 0;
    }
    
    if (hasStage && stateChanges.find("stage") != stateChanges.end()) {
        stateChanges["stageLen"] = 255;
        stateChanges["algorithm"] = 1;
        stateChanges["regime"] = 3;
    }
    
    if (hasRegime) {
        stateChanges["regime"] = regime;
    }
    
    if (hasControlSource) {
        stateChanges["controlSource"] = controlSource;
    }
    
    if (!stateChanges.empty()) {
        changeState(stateChanges);
        
        // Если controlSource неизвестен, запросить его
        if (state_.controlSource == 255) {
            requestOperationMode();
        }
    }
}

void SpectrObject::processSNMPVarbind(const SNMPVarbind& varbind) {
    // Игнорируем некоторые OID
    if (varbind.oid == SNMPOID::UTC_REPLY_GN + ".14" ||
        varbind.oid == SNMPOID::UTC_REPLY_GN + ".15" ||
        varbind.oid == SNMPOID::UTC_REPLY_BY_EXCEPTION ||
        varbind.oid == SNMPOID::SYS_UP_TIME ||
        varbind.oid == SNMPOID::SNMP_TRAP_OID) {
        return;
    }
    
    // Логирование неизвестных OID
    std::cout << "  ? " << varbind.oid << " " << varbind.type << " " << varbind.value << std::endl;
}

void SpectrObject::processCommand(const SpectrProtocol::ParsedCommand& command) {
    if (!command.isValid) {
        sendToITS(SpectrProtocol::formatResult(command.error, command.requestId));
        return;
    }
    
    SpectrError result = SpectrError::NOT_EXEC_3; // Incorrect command
    
    if (command.command == "SET_PHASE") {
        if (!command.params.empty()) {
            try {
                uint8_t phase = static_cast<uint8_t>(std::stoi(command.params[0]));
                result = setPhase(command.requestId, phase);
            } catch (...) {
                result = SpectrError::BAD_PARAM;
            }
        } else {
            result = SpectrError::BAD_PARAM;
        }
    } else if (command.command == "SET_YF") {
        result = setYF(command.requestId);
    } else if (command.command == "SET_OS") {
        result = setOS(command.requestId);
    } else if (command.command == "SET_LOCAL") {
        result = setLocal(command.requestId);
    } else if (command.command == "SET_START") {
        result = setStart(command.requestId);
    } else if (command.command == "GET_STAT") {
        std::string response = getStat(command.requestId);
        sendToITS(response);
        return;
    } else if (command.command == "GET_REFER") {
        std::string response = getRefer(command.requestId);
        sendToITS(response);
        return;
    } else if (command.command == "GET_CONFIG") {
        if (command.params.size() >= 2) {
            try {
                uint32_t param1 = std::stoul(command.params[0]);
                uint32_t param2 = std::stoul(command.params[1]);
                std::string response = getConfig(command.requestId, param1, param2);
                sendToITS(response);
                return;
            } catch (...) {
                result = SpectrError::BAD_PARAM;
            }
        } else {
            result = SpectrError::BAD_PARAM;
        }
    } else if (command.command == "GET_DATE") {
        std::string response = getDate(command.requestId);
        sendToITS(response);
        return;
    } else if (command.command == "SET_EVENT") {
        if (!command.params.empty()) {
            try {
                uint16_t mask = static_cast<uint16_t>(std::stoi(command.params[0]));
                if (mask >= 0 && mask <= 65535) {
                    eventMask_ = mask | 1;
                    result = SpectrError::OK;
                } else {
                    result = SpectrError::BAD_PARAM;
                }
            } catch (...) {
                result = SpectrError::BAD_PARAM;
            }
        } else {
            result = SpectrError::BAD_PARAM;
        }
    }
    
    sendToITS(SpectrProtocol::formatResult(result, command.requestId));
}

void SpectrObject::sendEvent(uint8_t eventType, const std::vector<std::string>& params) {
    uint16_t counter = ++eventCounter_;
    counter &= 0xFFFF;
    
    std::string event = SpectrProtocol::formatEvent(counter, eventType, params);
    sendToITS(event);
}

void SpectrObject::updateState() {
    auto now = std::chrono::system_clock::now();
    auto nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();
    
    if (stageStartTime_ > 0) {
        state_.stageCounter = static_cast<uint16_t>((nowMs - stageStartTime_) / 1000);
    } else {
        state_.stageCounter = 0;
    }
    
    if (cycleStartTime_ > 0) {
        state_.cicleCounter = static_cast<uint16_t>((nowMs - cycleStartTime_) / 1000);
    } else {
        state_.cicleCounter = 0;
    }
}

void SpectrObject::changeState(const std::map<std::string, uint8_t>& changes) {
    bool controlSourceChanged = false;
    bool stageChanged = false;
    
    std::vector<std::string> controlSourceFields = {"controlSource", "algorithm", "plan", "regime"};
    std::vector<std::string> stageFields = {"stage", "stageLen", "transition"};
    
    for (const auto& change : changes) {
        if (change.first == "stage" && state_.stage != change.second) {
            auto now = std::chrono::system_clock::now();
            stageStartTime_ = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()).count();
            if (change.second == 1) {
                cycleStartTime_ = stageStartTime_;
            }
        }
        
        // Обновление состояния
        if (change.first == "controlSource") state_.controlSource = change.second;
        else if (change.first == "algorithm") state_.algorithm = change.second;
        else if (change.first == "plan") state_.plan = change.second;
        else if (change.first == "regime") state_.regime = change.second;
        else if (change.first == "stage") state_.stage = change.second;
        else if (change.first == "stageLen") state_.stageLen = change.second;
        else if (change.first == "transition") state_.transition = change.second;
        
        if (std::find(controlSourceFields.begin(), controlSourceFields.end(), change.first) != controlSourceFields.end()) {
            controlSourceChanged = true;
        }
        if (std::find(stageFields.begin(), stageFields.end(), change.first) != stageFields.end()) {
            stageChanged = true;
        }
    }
    
    // Отправка событий
    if ((eventMask_ & 0x10) && stageChanged) {
        std::vector<std::string> params = {
            std::to_string(state_.stage),
            std::to_string(state_.stageLen),
            std::to_string(state_.transition)
        };
        sendEvent(4, params);
    }
    
    if ((eventMask_ & 0x08) && controlSourceChanged) {
        std::vector<std::string> params = {
            "1",
            std::to_string(state_.controlSource),
            std::to_string(state_.algorithm),
            std::to_string(state_.plan),
            std::to_string(state_.regime)
        };
        sendEvent(3, params);
    }
}

SpectrError SpectrObject::setPhase(const std::string& requestId, uint8_t phase) {
    if (phase < 1 || phase > 7) {
        return SpectrError::BAD_PARAM;
    }
    
    if (!snmpHandler_) {
        return SpectrError::NOT_EXEC_5; // Internal error
    }
    
    std::vector<SNMPVarbind> varbinds;
    
    // Установка режима работы в удаленный (3)
    SNMPVarbind modeVarbind;
    modeVarbind.oid = SNMPOID::UTC_TYPE2_OPERATION_MODE;
    modeVarbind.type = ASN_INTEGER;
    modeVarbind.value = "3";
    varbinds.push_back(modeVarbind);
    
    // Установка фазы через Force Bits (utcControlFn)
    SNMPVarbind phaseVarbind;
    phaseVarbind.oid = SNMPOID::UTC_CONTROL_FN;
    phaseVarbind.type = ASN_OCTET_STR;
    // Bit mask: 1 << (phase - 1)
    uint8_t bitMask = 1 << (phase - 1);
    phaseVarbind.value = std::string(1, static_cast<char>(bitMask));
    varbinds.push_back(phaseVarbind);
    
    bool success = false;
    snmpHandler_->set(config_.addr, varbinds, [&success, this, requestId](bool error, const std::vector<SNMPVarbind>&) {
        success = !error;
        if (!success) {
            std::cerr << "SET_PHASE failed for " << config_.addr << std::endl;
        }
    });
    
    return success ? SpectrError::OK : SpectrError::NOT_EXEC_5;
}

SpectrError SpectrObject::setYF(const std::string& requestId) {
    if (!snmpHandler_) {
        return SpectrError::NOT_EXEC_5;
    }
    
    std::vector<SNMPVarbind> varbinds;
    
    SNMPVarbind modeVarbind;
    modeVarbind.oid = SNMPOID::UTC_TYPE2_OPERATION_MODE;
    modeVarbind.type = ASN_INTEGER;
    modeVarbind.value = "3";
    varbinds.push_back(modeVarbind);
    
    SNMPVarbind ffVarbind;
    ffVarbind.oid = SNMPOID::UTC_CONTROL_FF;
    ffVarbind.type = ASN_INTEGER;
    ffVarbind.value = "1";
    varbinds.push_back(ffVarbind);
    
    bool success = false;
    snmpHandler_->set(config_.addr, varbinds, [&success](bool error, const std::vector<SNMPVarbind>&) {
        success = !error;
    });
    
    return success ? SpectrError::OK : SpectrError::NOT_EXEC_5;
}

SpectrError SpectrObject::setOS(const std::string& requestId) {
    if (!snmpHandler_) {
        return SpectrError::NOT_EXEC_5;
    }
    
    std::vector<SNMPVarbind> varbinds;
    
    SNMPVarbind modeVarbind;
    modeVarbind.oid = SNMPOID::UTC_TYPE2_OPERATION_MODE;
    modeVarbind.type = ASN_INTEGER;
    modeVarbind.value = "3";
    varbinds.push_back(modeVarbind);
    
    SNMPVarbind loVarbind;
    loVarbind.oid = SNMPOID::UTC_CONTROL_LO;
    loVarbind.type = ASN_INTEGER;
    loVarbind.value = "1";
    varbinds.push_back(loVarbind);
    
    bool success = false;
    snmpHandler_->set(config_.addr, varbinds, [&success](bool error, const std::vector<SNMPVarbind>&) {
        success = !error;
    });
    
    return success ? SpectrError::OK : SpectrError::NOT_EXEC_5;
}

SpectrError SpectrObject::setLocal(const std::string& requestId) {
    if (!snmpHandler_) {
        return SpectrError::NOT_EXEC_5;
    }
    
    std::vector<SNMPVarbind> varbinds;
    
    SNMPVarbind loVarbind;
    loVarbind.oid = SNMPOID::UTC_CONTROL_LO;
    loVarbind.type = ASN_INTEGER;
    loVarbind.value = "0";
    varbinds.push_back(loVarbind);
    
    SNMPVarbind ffVarbind;
    ffVarbind.oid = SNMPOID::UTC_CONTROL_FF;
    ffVarbind.type = ASN_INTEGER;
    ffVarbind.value = "0";
    varbinds.push_back(ffVarbind);
    
    SNMPVarbind modeVarbind;
    modeVarbind.oid = SNMPOID::UTC_TYPE2_OPERATION_MODE;
    modeVarbind.type = ASN_INTEGER;
    modeVarbind.value = "1";
    varbinds.push_back(modeVarbind);
    
    bool success = false;
    snmpHandler_->set(config_.addr, varbinds, [&success](bool error, const std::vector<SNMPVarbind>&) {
        success = !error;
    });
    
    return success ? SpectrError::OK : SpectrError::NOT_EXEC_5;
}

SpectrError SpectrObject::setStart(const std::string& requestId) {
    if (!snmpHandler_) {
        return SpectrError::NOT_EXEC_5;
    }
    
    std::vector<SNMPVarbind> varbinds;
    
    SNMPVarbind startVarbind;
    startVarbind.oid = SNMPOID::UTC_CONTROL_FN + ".5";
    startVarbind.type = ASN_INTEGER;
    startVarbind.value = "1";
    varbinds.push_back(startVarbind);
    
    SNMPVarbind modeVarbind;
    modeVarbind.oid = SNMPOID::UTC_TYPE2_OPERATION_MODE;
    modeVarbind.type = ASN_INTEGER;
    modeVarbind.value = "1";
    varbinds.push_back(modeVarbind);
    
    bool success = false;
    snmpHandler_->set(config_.addr, varbinds, [&success](bool error, const std::vector<SNMPVarbind>&) {
        success = !error;
    });
    
    return success ? SpectrError::OK : SpectrError::NOT_EXEC_5;
}

std::string SpectrObject::getStat(const std::string& requestId) {
    updateState();
    
    std::stringstream ss;
    ss << "STAT " << static_cast<int>(state_.damage) << " "
       << static_cast<int>(state_.error) << " "
       << static_cast<int>(state_.unitsGood) << " "
       << static_cast<int>(state_.units) << " "
       << static_cast<int>(state_.powerFlags) << " "
       << static_cast<int>(state_.controlSource) << " "
       << static_cast<int>(state_.algorithm) << " "
       << static_cast<int>(state_.plan) << " "
       << state_.cicleCounter << " "
       << static_cast<int>(state_.stage) << " "
       << static_cast<int>(state_.stageLen) << " "
       << state_.stageCounter << " "
       << static_cast<int>(state_.transition) << " "
       << static_cast<int>(state_.regime) << " "
       << static_cast<int>(state_.testMode) << " "
       << static_cast<int>(state_.syncError) << " "
       << static_cast<int>(state_.dynamicFlags);
    
    return SpectrProtocol::formatResult(SpectrError::OK, requestId, ss.str());
}

std::string SpectrObject::getRefer(const std::string& requestId) {
    std::stringstream ss;
    ss << "\"Spectr\" " << config_.id << " \"" << config_.strid << "\"";
    return SpectrProtocol::formatResult(SpectrError::OK, requestId, ss.str());
}

std::string SpectrObject::getConfig(const std::string& requestId, uint32_t param1, uint32_t param2) {
    std::string configText;
    if (param1 == 0 && param2 == 0) {
        configText = "#TxtCfg Spectr:" + config_.strid + " ";
    } else {
        configText = "BEGIN:\nEND.\n";
    }
    
    std::string hexConfig = SpectrProtocol::toHex(configText);
    std::stringstream ss;
    ss << "0 0 [" << hexConfig << "]";
    return SpectrProtocol::formatResult(SpectrError::OK, requestId, ss.str());
}

std::string SpectrObject::getDate(const std::string& requestId) {
    std::time_t now = std::time(nullptr);
    std::tm* local = std::localtime(&now);
    
    std::stringstream ss;
    ss << local->tm_mday << "/" << (local->tm_mon + 1) << "/" << (1900 + local->tm_year);
    return SpectrProtocol::formatResult(SpectrError::OK, requestId, ss.str());
}

void SpectrObject::sendToITS(const std::string& data) {
    std::cout << config_.id << " <- " << data;
    if (tcpClient_) {
        tcpClient_->send(data);
    }
}

void SpectrObject::requestOperationMode() {
    if (!snmpHandler_) {
        return;
    }
    
    std::vector<std::string> oids = {SNMPOID::UTC_TYPE2_OPERATION_MODE};
    
    snmpHandler_->get(config_.addr, oids, [this](bool error, const std::vector<SNMPVarbind>& varbinds) {
        if (!error && !varbinds.empty()) {
            try {
                int value = std::stoi(varbinds[0].value);
                uint8_t controlSource = (value == 3) ? 3 : 1;
                changeState({{"controlSource", controlSource}});
            } catch (...) {
                std::cerr << "Failed to parse operation mode" << std::endl;
            }
        }
    });
}
