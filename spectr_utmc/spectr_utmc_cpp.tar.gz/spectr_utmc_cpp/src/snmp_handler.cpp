#include "snmp_handler.h"
#include <iostream>
#include <cstring>
#include <sstream>
#include <algorithm>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <netsnmp/varbind_api.h>
#include <netsnmp/pdu_api.h>

SNMPHandler::SNMPHandler(const std::string& community)
    : community_(community), receiverRunning_(false), receiverSocket_(-1) {
    init_snmp("spectr_utmc_cpp");
}

SNMPHandler::~SNMPHandler() {
    stopReceiver();
    
    for (auto& pair : sessions_) {
        if (pair.second) {
            snmp_close(pair.second);
        }
    }
    sessions_.clear();
}

bool SNMPHandler::createSession(const std::string& address, const std::string& community) {
    if (sessions_.find(address) != sessions_.end()) {
        return true; // Сессия уже существует
    }
    
    netsnmp_session session;
    snmp_sess_init(&session);
    session.peername = strdup(address.c_str());
    session.version = SNMP_VERSION_2c;
    session.community = reinterpret_cast<u_char*>(strdup(community.c_str()));
    session.community_len = community.length();
    
    netsnmp_session* ss = snmp_open(&session);
    if (ss == nullptr) {
        std::cerr << "Failed to create SNMP session for " << address << std::endl;
        return false;
    }
    
    sessions_[address] = ss;
    return true;
}

bool SNMPHandler::startReceiver(uint16_t port, NotificationCallback callback) {
    if (receiverRunning_) {
        return false;
    }
    
    notificationCallback_ = callback;
    receiverRunning_ = true;
    receiverThread_ = std::thread(&SNMPHandler::receiverThread, this, port);
    return true;
}

void SNMPHandler::stopReceiver() {
    if (!receiverRunning_) {
        return;
    }
    
    receiverRunning_ = false;
    
    if (receiverSocket_ >= 0) {
        close(receiverSocket_);
        receiverSocket_ = -1;
    }
    
    if (receiverThread_.joinable()) {
        receiverThread_.join();
    }
}

void SNMPHandler::receiverThread(uint16_t port) {
    // Используем net-snmp API для приема traps/informs
    netsnmp_session session;
    snmp_sess_init(&session);
    session.version = SNMP_VERSION_2c;
    session.community = reinterpret_cast<u_char*>(strdup(community_.c_str()));
    session.community_len = community_.length();
    
    // Создание транспорта для приема на указанном порту
    netsnmp_transport* transport = netsnmp_udp_transport(port, 1);
    if (transport == nullptr) {
        std::cerr << "Failed to create UDP transport on port " << port << std::endl;
        receiverRunning_ = false;
        return;
    }
    
    netsnmp_session* ss = snmp_open(&session);
    if (ss == nullptr) {
        std::cerr << "Failed to create SNMP session for receiver" << std::endl;
        netsnmp_transport_free(transport);
        receiverRunning_ = false;
        return;
    }
    
    // Привязка транспорта к сессии
    ss->transport = transport;
    
    receiverSocket_ = transport->sock;
    
    std::cout << "SNMP receiver started on port " << port << std::endl;
    
    while (receiverRunning_) {
        fd_set readFds;
        FD_ZERO(&readFds);
        FD_SET(transport->sock, &readFds);
        
        struct timeval timeout;
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;
        
        int result = select(transport->sock + 1, &readFds, nullptr, nullptr, &timeout);
        
        if (result > 0 && FD_ISSET(transport->sock, &readFds)) {
            netsnmp_pdu* pdu = nullptr;
            netsnmp_transport* recvTransport = nullptr;
            
            int status = snmp_sess_read(ss, &pdu, &recvTransport);
            
            if (status == SNMPERR_SUCCESS && pdu != nullptr) {
                processNotification(pdu, recvTransport, this);
                snmp_free_pdu(pdu);
            } else if (status != SNMPERR_TIMEOUT) {
                // Ошибка чтения (но не таймаут)
                std::cerr << "SNMP read error: " << snmp_errstring(status) << std::endl;
            }
        }
    }
    
    snmp_close(ss);
    receiverSocket_ = -1;
}

void SNMPHandler::processNotification(netsnmp_pdu* pdu, netsnmp_transport* transport, void* context) {
    SNMPHandler* handler = static_cast<SNMPHandler*>(context);
    
    SNMPNotification notification;
    
    // Получение адреса источника
    if (transport && transport->remote_name) {
        notification.sourceAddress = transport->remote_name;
    } else if (transport && transport->remote_length > 0) {
        // Альтернативный способ получения адреса
        struct sockaddr_in* sin = (struct sockaddr_in*)transport->remote;
        if (sin) {
            char addrStr[INET_ADDRSTRLEN];
            inet_ntop(AF_INET, &sin->sin_addr, addrStr, INET_ADDRSTRLEN);
            notification.sourceAddress = addrStr;
        }
    }
    
    // Обработка varbinds из PDU
    for (netsnmp_variable_list* vars = pdu->variables; vars != nullptr; vars = vars->next_variable) {
        SNMPVarbind varbind;
        
        char oidBuf[1024];
        snprint_objid(oidBuf, sizeof(oidBuf), vars->name, vars->name_length);
        varbind.oid = oidBuf;
        varbind.type = vars->type;
        
        char valueBuf[1024];
        snprint_value(valueBuf, sizeof(valueBuf), vars->name, vars->name_length, vars);
        varbind.value = valueBuf;
        
        notification.varbinds.push_back(varbind);
    }
    
    if (handler->notificationCallback_) {
        handler->notificationCallback_(notification);
    }
}

bool SNMPHandler::get(const std::string& address, const std::vector<std::string>& oids,
                      std::function<void(bool error, const std::vector<SNMPVarbind>&)> callback) {
    netsnmp_session* session = getSession(address);
    if (session == nullptr) {
        if (!createSession(address, community_)) {
            if (callback) callback(true, {});
            return false;
        }
        session = getSession(address);
    }
    
    if (session == nullptr) {
        if (callback) callback(true, {});
        return false;
    }
    
    netsnmp_pdu* pdu = snmp_pdu_create(SNMP_MSG_GET);
    if (pdu == nullptr) {
        if (callback) callback(true, {});
        return false;
    }
    
    for (const auto& oidStr : oids) {
        oid oidBuf[MAX_OID_LEN];
        size_t oidLen = MAX_OID_LEN;
        
        if (!snmp_parse_oid(oidStr.c_str(), oidBuf, &oidLen)) {
            snmp_free_pdu(pdu);
            if (callback) callback(true, {});
            return false;
        }
        
        snmp_add_null_var(pdu, oidBuf, oidLen);
    }
    
    netsnmp_pdu* response = nullptr;
    int status = snmp_sess_sync_response(session, pdu, &response);
    
    std::vector<SNMPVarbind> varbinds;
    bool hasError = (status != STAT_SUCCESS || response == nullptr);
    
    if (!hasError && response->errstat == SNMP_ERR_NOERROR) {
        for (netsnmp_variable_list* vars = response->variables; vars != nullptr; vars = vars->next_variable) {
            SNMPVarbind varbind;
            
            char oidBuf[1024];
            snprint_objid(oidBuf, sizeof(oidBuf), vars->name, vars->name_length);
            varbind.oid = oidBuf;
            varbind.type = vars->type;
            
            char valueBuf[1024];
            snprint_value(valueBuf, sizeof(valueBuf), vars->name, vars->name_length, vars);
            varbind.value = valueBuf;
            
            varbinds.push_back(varbind);
        }
    } else {
        hasError = true;
    }
    
    if (response) {
        snmp_free_pdu(response);
    }
    
    if (callback) {
        callback(hasError, varbinds);
    }
    
    return !hasError;
}

bool SNMPHandler::set(const std::string& address, const std::vector<SNMPVarbind>& varbinds,
                      std::function<void(bool error, const std::vector<SNMPVarbind>&)> callback) {
    netsnmp_session* session = getSession(address);
    if (session == nullptr) {
        if (!createSession(address, community_)) {
            if (callback) callback(true, {});
            return false;
        }
        session = getSession(address);
    }
    
    if (session == nullptr) {
        if (callback) callback(true, {});
        return false;
    }
    
    netsnmp_pdu* pdu = snmp_pdu_create(SNMP_MSG_SET);
    if (pdu == nullptr) {
        if (callback) callback(true, {});
        return false;
    }
    
    for (const auto& varbind : varbinds) {
        oid oidBuf[MAX_OID_LEN];
        size_t oidLen = MAX_OID_LEN;
        
        if (!snmp_parse_oid(varbind.oid.c_str(), oidBuf, &oidLen)) {
            snmp_free_pdu(pdu);
            if (callback) callback(true, {});
            return false;
        }
        
        // Определение типа и значения
        if (varbind.type == ASN_INTEGER) {
            long intValue = std::stol(varbind.value);
            snmp_pdu_add_variable(pdu, oidBuf, oidLen, ASN_INTEGER, &intValue, sizeof(intValue));
        } else if (varbind.type == ASN_OCTET_STR) {
            snmp_pdu_add_variable(pdu, oidBuf, oidLen, ASN_OCTET_STR, 
                                 const_cast<char*>(varbind.value.c_str()), varbind.value.length());
        } else {
            // Для других типов нужна дополнительная обработка
            snmp_free_pdu(pdu);
            if (callback) callback(true, {});
            return false;
        }
    }
    
    netsnmp_pdu* response = nullptr;
    int status = snmp_sess_sync_response(session, pdu, &response);
    
    std::vector<SNMPVarbind> resultVarbinds;
    bool hasError = (status != STAT_SUCCESS || response == nullptr);
    
    if (!hasError && response->errstat == SNMP_ERR_NOERROR) {
        for (netsnmp_variable_list* vars = response->variables; vars != nullptr; vars = vars->next_variable) {
            SNMPVarbind varbind;
            
            char oidBuf[1024];
            snprint_objid(oidBuf, sizeof(oidBuf), vars->name, vars->name_length);
            varbind.oid = oidBuf;
            varbind.type = vars->type;
            
            char valueBuf[1024];
            snprint_value(valueBuf, sizeof(valueBuf), vars->name, vars->name_length, vars);
            varbind.value = valueBuf;
            
            resultVarbinds.push_back(varbind);
        }
    } else {
        hasError = true;
    }
    
    if (response) {
        snmp_free_pdu(response);
    }
    
    if (callback) {
        callback(hasError, resultVarbinds);
    }
    
    return !hasError;
}

netsnmp_session* SNMPHandler::getSession(const std::string& address) {
    auto it = sessions_.find(address);
    if (it != sessions_.end()) {
        return it->second;
    }
    return nullptr;
}
